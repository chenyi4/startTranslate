function h=r2h(r)
% change radius to hour

h=r2d(r/15);