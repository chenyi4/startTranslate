function s=sign1(x)
%sign of real x: 1 for zero or positive, -1 for negative
s=1;
if x<0
   s=-1;
end

